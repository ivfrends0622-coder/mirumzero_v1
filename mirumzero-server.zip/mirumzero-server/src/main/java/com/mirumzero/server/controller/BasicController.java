package com.mirumzero.server.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/home")
public class BasicController {

    @GetMapping("/basic")
    public ResponseEntity<String> basic() {
        return ResponseEntity.ok("mirumzero");
    }
}
