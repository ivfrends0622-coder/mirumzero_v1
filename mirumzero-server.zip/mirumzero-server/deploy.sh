#!/bin/bash

# ============================
# EC2 Deploy Script
# mirumzero-server
# ============================

set -e

APP_NAME="mirumzero-server"
JAR_FILE="mirumzero-server.jar"
PORT=8080
LOG_FILE="/var/log/${APP_NAME}.log"
PID_FILE="/var/run/${APP_NAME}.pid"

echo "=============================="
echo " Deploying ${APP_NAME}"
echo "=============================="

# 1. Java 17 설치 확인
if ! java -version 2>&1 | grep -q "17\|21"; then
    echo "[INFO] Installing Java 17..."
    sudo apt-get update -y
    sudo apt-get install -y openjdk-17-jdk
fi

echo "[OK] Java version: $(java -version 2>&1 | head -1)"

# 2. 기존 프로세스 종료
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat $PID_FILE)
    if ps -p $OLD_PID > /dev/null 2>&1; then
        echo "[INFO] Stopping existing process (PID: $OLD_PID)..."
        kill $OLD_PID
        sleep 3
    fi
    rm -f $PID_FILE
fi

# 포트 점유 프로세스 강제 종료
EXISTING_PID=$(lsof -ti:$PORT 2>/dev/null || true)
if [ -n "$EXISTING_PID" ]; then
    echo "[INFO] Killing process on port $PORT (PID: $EXISTING_PID)..."
    kill -9 $EXISTING_PID
    sleep 2
fi

# 3. JAR 실행
echo "[INFO] Starting ${JAR_FILE}..."
nohup java -jar ${JAR_FILE} \
    --spring.profiles.active=prod \
    > ${LOG_FILE} 2>&1 &

NEW_PID=$!
echo $NEW_PID > $PID_FILE

echo "[INFO] Server started with PID: $NEW_PID"
echo "[INFO] Log file: ${LOG_FILE}"

# 4. 헬스체크
echo "[INFO] Waiting for server to start..."
sleep 8

for i in {1..10}; do
    if curl -s http://localhost:${PORT}/home/basic | grep -q "mirumzero"; then
        echo "[OK] Server is running! Response: $(curl -s http://localhost:${PORT}/home/basic)"
        break
    fi
    echo "[INFO] Attempt ${i}/10 - waiting..."
    sleep 3
done

echo "=============================="
echo " Deploy Complete!"
echo " curl http://localhost:${PORT}/home/basic"
echo "=============================="
