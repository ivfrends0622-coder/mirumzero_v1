# Mirumzero Spring Boot Server

## 프로젝트 구조
```
mirumzero-server/
├── pom.xml
├── deploy.sh                          # EC2 배포 스크립트
├── mirumzero-server.service           # systemd 서비스 등록 파일
├── README.md
└── src/
    └── main/
        ├── java/com/mirumzero/server/
        │   ├── ServerApplication.java          # 메인 클래스
        │   └── controller/
        │       └── BasicController.java        # GET /home/basic → "mirumzero"
        └── resources/
            └── application.yml                # 서버 설정 (포트: 8080)
```

## API
| Method | URL | Response |
|--------|-----|----------|
| GET | /home/basic | mirumzero |

---

## EC2 배포 방법

### 1단계: 로컬에서 JAR 빌드
```bash
cd mirumzero-server
mvn clean package -DskipTests
# target/mirumzero-server.jar 생성됨
```

### 2단계: EC2로 파일 전송
```bash
scp -i your-key.pem target/mirumzero-server.jar ec2-user@<EC2-IP>:/home/ec2-user/app/
scp -i your-key.pem deploy.sh ec2-user@<EC2-IP>:/home/ec2-user/app/
```

### 3단계: EC2에서 실행
```bash
ssh -i your-key.pem ec2-user@<EC2-IP>
cd /home/ec2-user/app
chmod +x deploy.sh
./deploy.sh
```

### (선택) systemd로 자동 시작 등록
```bash
sudo cp mirumzero-server.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable mirumzero-server
sudo systemctl start mirumzero-server
sudo systemctl status mirumzero-server
```

---

## EC2 보안 그룹 설정
- **인바운드 규칙**에 포트 `8080` (TCP) 추가 필요
- 외부 접근: `http://<EC2-공인IP>:8080/home/basic`

## 테스트
```bash
curl http://localhost:8080/home/basic
# 응답: mirumzero
```
